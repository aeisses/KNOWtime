package com.knowtime;

import android.app.Activity;

public class MenuActivity extends Activity {

}
